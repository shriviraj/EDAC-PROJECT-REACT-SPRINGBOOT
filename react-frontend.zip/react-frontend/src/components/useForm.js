import { useState, useEffect } from "react";
import BASE_URL from './../services/UserService';
import axios from 'axios';

const useForm = (callback, validate) => {
  const [values, setValues] = useState({
    username: "",
    email: "",
    password: "",
    password2: "",
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    setErrors(validate(values));
    setIsSubmitting(true);
    console.log(values);
    postDataToServer(values);

  };

  const postDataToServer=(data)=>{
      console.log(data);
      axios.post(`${BASE_URL}/registration`,data).then(
          (response)=>{console.log(response);
            console.log('success');
        },
        (error)=>{
            console.log(error);
            console.log('error');
        }
      )
  }



  useEffect(() => {
    if (Object.keys(errors).length === 0 && isSubmitting) {
      callback();
    }
  }, [errors]);

  return { handleChange, handleSubmit, values, errors };
};

export default useForm;

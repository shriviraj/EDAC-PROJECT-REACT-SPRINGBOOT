import  { useState } from "react";
import { Jumbotron, Container } from "reactstrap";
import LoginSuccess from './LoginSuccess';

import Login from "./Login";

const Home = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  function submitForm() {
    setIsSubmitted(true);
  }

  return (
    <div className="home-container">
      <Jumbotron className="home-Educate">
        <h1 className="home-content">EducateNow</h1>
        
        <Container>
        {!isSubmitted ? (
          <Login submitForm={submitForm} />
        ) : (
          <LoginSuccess />
        )}
          
        </Container>
      </Jumbotron>
    </div>
  );
};
export default Home;
